﻿namespace MilitaryElite.Models.Interfaces;

public interface IRepair
{
    string PartName { get; }
    int HoursWorked { get; }
}