﻿namespace MilitaryElite.Models.Interfaces;

public interface ISpy : ISoldier
{
    int CodeNumber { get; }
}