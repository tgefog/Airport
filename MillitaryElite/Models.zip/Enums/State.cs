﻿namespace MilitaryElite.Enums;

public enum State
{
    inProgress,
    Finished
}