﻿namespace VehiclesExtension.IO.Interfaces;

public interface IWriter
{
    void WriteLine(string str);
}