﻿namespace _04.WildFarm.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string str);
    }
}
