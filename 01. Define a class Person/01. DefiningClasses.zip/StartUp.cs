﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person gosho=new Person();

            gosho.Name = "GoShow";
            gosho.Age = 25;
            Console.WriteLine($"{gosho.Name}:{gosho.Age}");
        }
    }
}
